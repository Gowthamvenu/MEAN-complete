/**
 * Created by Academy
 */

var Product = require('../models/Product.js');
var Order = require('../models/Order.js');

var HttpStatus = require('http-status');
var Validation = require('./Validation');
var mongoose = require('mongoose');
//Your controller variable is defined here
var ProductController = require('./ProductController.js');

//use exec to run a shell script for example
// if you want to create a folder then you can run exec('mkdir folderpath', callback function) 
var exec = require('child_process').exec;

//User node-fs to create files in a given folderr
var fs = require('node-fs');


//Implement the following functionalities

//save method to Save a new 
module.exports.save = function (req, res) {
    var newProduct = new Product();
    newProduct.name = req.body.name;
    newProduct.category = req.body.category;
    newProduct.description = req.body.description;
    newProduct.price = req.body.price;
    newProduct.save(function (saveErr, saveProduct) {
        if (saveErr) {
            res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                data: '',
                error: Validation.validationErrors(saveErr)
            });
            return;
        }
        ProductController.saveProductImg(saveProduct, function (err) {
            if (err) {
                res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
                    status: 'failure',
                    code: HttpStatus.INTERNAL_SERVER_ERROR,
                    data: '',
                    error: ''
                });
                return;
            }
            res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: saveProduct,
                error: ''
            });
        });

    });
}

//To set a default image for a new product implement and call
//saveProductImg to Save a default image for it
//default image: ./public/images/product.png
//create a folder in the path ./public/images/Product
//in the new folder create the image with 
//filename: _id+"_Product."+imageextension
//eg: if uploaded file is image.jpg for item with _id: abcdefghij
//then filename: abdefghij_Product.jpg 

module.exports.saveProductImg = function (product, cb) {
    var imgExtension = '.png';
    let product_id = product._id;
    let product_name = "Product";
    let product_image_name = product_id + "_" + product_name + imgExtension;
    var imgPath = './public/images/Product/' + product._id + "_" + "Product" + imgExtension;
    fs.readFile(process.cwd() + '/public/images/product' + imgExtension, function (err, data) {
        if (err) cb(err);

        if (!fs.existsSync('./public/images/Product')) {
            execSync('mkdir "./public/images/Product"', function (error, stdout, stderr) {
                if (error) {
                    cb(error)
                }

                if (fs.existsSync(imgPath)) {
                    fs.unlinkSync(imgPath);
                }

                fs.writeFile(process.cwd() + '/public/images/Product/' + product_image_name, data, function (err) {
                    if (err) {
                        cb(err);
                    }


                    product.productImg.fileName = product._id + "_" + "Product" + imgExtension;
                    product.productImg.filePath = imgPath;
                    product.productImg.fileType = imgExtension;
                    product.save(function (saveerr, savePicture) {
                        if (saveerr) {
                            cb(saveerr);
                        }
                        cb(null);
                    });
                });

            });
        } else {
            if (fs.existsSync(imgPath)) {
                fs.unlinkSync(imgPath);
            }

            fs.writeFile(process.cwd() + '/public/images/Product/' + product_image_name, data, function (err) {
                if (err) {
                    cb(err);
                }

                product.productImg.fileName = product._id + "_" + "Product" + imgExtension;
                product.productImg.filePath = imgPath;
                product.productImg.fileType = imgExtension;
                product.save(function (saveerr, savePicture) {
                    if (saveerr) {
                        cb(saveerr);
                    }
                    cb(null);
                });
            });
        }
    });

}

//list method to List all products in db
module.exports.list = function (req, res) {
    Product.find({}, function (err, product) {
        if (err) {
            res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
                status: 'failure',
                code: HttpStatus.INTERNAL_SERVER_ERROR,
                data: '',
                error: 'unexpected error in accessing data'
            });
        }
        res.status(HttpStatus.OK).json({
            status: 'success',
            code: HttpStatus.OK,
            data: product,
            error: ''
        });
    });
}

//fetchProductImg method to Fetch the productImage of a given product
module.exports.fetch_product_img = function (req, res) {

    Product.findById(req.params.id, function (err, productDoc) {
        if (err) {
            res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
                status: 'failure',
                code: HttpStatus.INTERNAL_SERVER_ERROR,
                data: '',
                error: 'unexpected error in accessing data'
            });
            return;
        }
        if (productDoc == null) {
            res.status(HttpStatus.NOT_FOUND).json({
                status: 'failure',
                code: HttpStatus.NOT_FOUND,
                error: 'Product image not found'
            });
            return;
        }
        res.end(fs.readFileSync(productDoc.productImg.filePath));
    });
}

//saveProducts method to seed the database with initial data
module.exports.saveProducts = function (req, res) {

    var productsDetails = [{
        "name" : "Mini Tiffin",
        "category" : "South Indian",
        "description" : "Rava Kesari, mini idly 5pcs, rava kichadi, mini masala dosai",
        "price" : "123"
    },{
        "name" : "Big Boy Burger",
        "category" : "American",
        "description" : "Double patty burger with cheese and fries",
        "price" : "500"
    },{
        "name" : "Melanzane Parmagianna",
        "category" : "Italian",
        "description" : "Baked layers of sliced aubergine with fresh basil, mozarella, tomato sauce, sprinkled with parmesan cheese",
        "price" : "450"
    },{
        "name" : "Sebze Kefta Tagine",
        "category" : "Mediterranean",
        "description" : "Cottage cheese mince with garlic, fresh coriander and parsley, cinnamon is rolled into balls and cooked in a tomato and onion sauce",
        "price" : "532"
    }];

    for(var i=0; i< productsDetails.length;i++){
        var newProduct = new Product();
        var product = productsDetails[i];
        newProduct.name = product.name;
        newProduct.category = product.category;
        newProduct.description = product.description;
        newProduct.price = product.price;
        newProduct.save(function (saveErr, saveProduct) {
        if (saveErr) {
                console.log(Validation.validationErrors(saveErr));
                return;
            }
            ProductController.saveProductImg(saveProduct, function (err) {
                if (err) {
                    throw new Error(err);
                }
            });
        });
    }

    /* var newProduct = new Product();
    newProduct.name = "Dosa";
    newProduct.category = "SOUTH INDIAN";
    newProduct.description = "Plain and crispy";
    newProduct.price = "70";
    newProduct.save(function (saveErr, saveProduct) {
        if (saveErr) {
            console.log(Validation.validationErrors(saveErr));
            return;
        }
        ProductController.saveProductImg(saveProduct, function (err) {
            if (err) {
                throw new Error(err);
            }
        });
    }); */

}

//Implemenet the saveOrder method here
//Include the Order Schema into this controller
//Save the incoming order to the Order collection
module.exports.saveOrder = function (req, res) {

    var order = new Order(req.body);

    order.save(function (saveErr, saveOrderDetails) {
        if (saveErr) {
            res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                data: '',
                error: Validation.validationErrors(saveErr)
            });
            return;
        }
        res.status(HttpStatus.OK).json({
            status: 'success',
            code: HttpStatus.OK,
            data: saveOrderDetails,
            error: ''
        });
    });

}

