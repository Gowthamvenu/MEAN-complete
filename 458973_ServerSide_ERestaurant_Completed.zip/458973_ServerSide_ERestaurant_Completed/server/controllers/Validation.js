/**
 * Created by Academy
 */

//Create a Validation method
//Capture any schema validation errors
//Check the error type and 
//Return a meaningfull message that the user will be able to understand 

module.exports.validationErrors=function(err){
    var errors={};
    if (err) {
        switch (err.name) {
            case 'ValidationError':
                for (field in err.errors) {
                    switch (err.errors[field].name) {
                        case 'ValidatorError':
                        if(err.errors[field].kind === 'required'){
                            errors[field] = [field] + ' is Required';
                        }
                        if(err.errors[field].kind === 'user defined'){
                            errors[field] = 'Already Exist';
                        }
                        if(err.errors[field].kind === 'unique'){
                            errors[field] = 'Already Exist';
                        }
                        if(err.errors[field].kind === 'enum'){
                            errors[field] = 'Invalid ' + [field];
                        }
                        break;
                        
                        case 'CastError':
                        if (err.errors[field].kind === 'Number') {
                            errors[field] = [field] + ' must be a Number';
                        }
                        if (err.errors[field].kind === 'date') {
                            errors[err.path] = [err.path] + ' must be a Valid Date';
                        }
                        if (err.errors[field].kind === 'ObjectId') {
                            errors[err.path] = [err.path] + ' is NotValid';
                        }
                        break;
                    }
                }
            break;
        }
        
    }
    return errors;
  }