/**
 * Created by Academy
 */
var mongoose = require('mongoose');
Schema = mongoose.Schema;

//Define your order schema here

var item=new Schema({
        name: {
            type:String,
            required:true
        },
        category:{
            type: String,
            required:true
        }, 
        description:{
            type: String,
            required:true
        }, 
        price:{
            type:Number,
            required: true
        } 
});

var Order=new Schema({
    items:[item],
    checkoutDetails : {
        name: {
            type: String,
            required:true 
        },
        address:{
            line1: {
                type: String,
                required:true 
            },
            country: {
                type: String,
                required:true 
            },
            state: {
                type: String,
                required:true 
            },
            pinCode: {
                type: String,
                required:true 
            }
        },
        total: {
            type: Number,
            required:true 
        },
        date:{
            type: Date,
            required:true 
        } 
    }
})
module.exports=mongoose.model("Order",Order);
