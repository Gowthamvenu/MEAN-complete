/**
 * Created by Academy
 */
var mongoose = require('mongoose');
Schema = mongoose.Schema;

var uniqueValidator = require('mongoose-unique-validator');

//Define your product schema here
//Attributes to be Created
//Name - name of the menu item
//Category - cuisine to which the menu belongs to
//Description - a short description of the item
//Price - The price of the item
//productImg - filepath to the image
// 
//Use the mongoose-unique-validator plugin to validate for uniqueness
//

var Product = new Schema({
    name: {
        type: String,
        required:true,
        unique: true
    },
    category: {
        type:String,
        required: true
    },
    description: {
        type:String,
        required: true
    },
    price: {
        type: Number,
        required:true
    },
    productImg: {
        fileName: {
            type: String
        },
        filePath: {
            type: String
        },
        fileType: {
            type: String
        }
    }
});
Product.plugin(uniqueValidator,{ type: 'unique' , message: '{VALUE} already exists' });
module.exports = mongoose.model("Product", Product);