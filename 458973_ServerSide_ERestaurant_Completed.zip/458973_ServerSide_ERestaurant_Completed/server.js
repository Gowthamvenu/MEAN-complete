/**
 * Created by Academy
 */
var express = require('express');
var app = express();
var port = 3001;
var bodyParser = require('body-parser');
var cors = require('cors');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var morgan = require('morgan');
var mongoose = require('mongoose');

app.use(cors());

var User = require('./server/controllers/UserController.js');
var Product = require('./server/controllers/ProductController.js');
User.saveAdmin();
//TODO Please use the below call to seed products in the backend
Product.saveProducts();

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/myapp',function(error){
    if(error) console.log(error);
    console.log('connected to db');
});
/**
 * Including mongoose promise since mongoose's default promise library is deprecated
 */
mongoose.Promise=global.Promise;

app.use(bodyParser.urlencoded({limit: '50mb',extended: true}));
app.use(bodyParser.json({limit: '50mb'}));
app.set('view engine', 'ejs');

app.use(morgan('dev'));
app.use(express.static('public'));
app.use(cookieParser());
app.use(session({secret: 'secret key', resave: true, saveUninitialized: true,cookie: { path: '/', httpOnly: true, maxAge: 30 * 300000 },rolling: true}));

require("./server/routes.js")(app);

app.listen(port);
console.log('App is listening on port: ' + port);