CODE SETUP
To test the code, basic requirements are a 64 bit Windows OS, MongoDB, NodeJS, npm, Robo Mongo and Visual Studio Code.
Clone the repository to local or just download the zip file.
Some times while extracting a zip, you might face a error filepath too long.
In such cases either rename the zip file to a small word and extract. (Or) skip all.
Rather rename(smaller name) the zip file if you are a NOVIVCE.
If you have done skip all, then you have to run npm install to install all the dependencies.

MONGODB
Start the MongoDB, navigate to bin directory of MongoDB 
Open cmd from the directory and type mongod.exe
Again open another cmd in the same directory and type mongo.exe

NODEJS
In code setp if you have skipped filed while extracting then type command "npm install" in Visual Studio Code.
Else directly run "node server.js" command.

Open browser, type url localhost:3001. 
You can change the port no in server.js file(if required).

Happy Learning.